﻿/// <reference path="c:\soft\pwx\link\pwxscohn_jquery_html5.js" />
'use strict';

function Pxcsemhn() {}

Pxcsemhn.prototype = {
    load: function () {
        oPxcsemhn.clienteTpPessoa();
        oInfra.getUtil().setarGroupRadio('rdTipoPessoaLista', oInfra.getProduto().getParametros().getItem('xcTpPessoa'));
        $('#txtNomeClienteLista').val(oInfra.getProduto().getParametros().getItem('xcNomeCli'));

        oInfra.getUtil().setarGroupRadio('rdTipoPessoaCadastro', oInfra.getProduto().getParametros().getItem('xcTpPessoa'));

        $('#txtNomeClienteCadastro').val(oInfra.getProduto().getParametros().getItem('xcNomeCli'));

        $('#btnNovoLista').click(this.clicarNovo);
        $('#btnVoltarLista').click(function () {
            oInfra.getServidor().invocarPagina('M5CL');
        });
        $('#btnNovoCadastro').click(this.clicarNovo);
        $('#btnIncluirCadastro').click(this.clicarIncluir);
        $('#btnSalvarCadastro').click(this.clicarSalvar);
        $('#btnHabilitarCadastro').click(function () {
            oInfra.getTela().clicarHabilitarCadastro();
        });
        $('#btnPagar').click(this.clicarOutro);
        $('#btnCancelar').click(this.clicarOutro);
        $('#btnExcluirCadastro').click(this.clicarExcluir);
        $('#btnLimparCadastroCadastro').click(function () {
            oInfra.getTela().limparCamposAtivosFormulario('#boxDadosCadastro');
        });
        $('#btnVoltarCadastro').click(function () {
            oInfra.getTela().clicarBotaoVoltar();
        });
        
        $('#txtCadastroUf').change(oPxcsemhn.CodMun);
        this.clicarPesquisar();
        oInfra.getUtil().carregarValidador();
        oPxcsemhn.carregarTxtCadastroAgencia();
        this.carregarTxtCadastroAgencia();    

    },
    CodMun: function () {
        switch ($('#txtCadastroUf').val()) {
            case 'RS':
                    oPxcsemhn.carregarTxtCadastroCodMunicipio();
                break;
            case 'SC':
                    oPxcsemhn.carregarTxtCadastroCodMunicipio();
                break;
            case 'PR':
                    oPxcsemhn.carregarTxtCadastroCodMunicipio();
                break;
            default:
                    $('#txtCadastroCodMunicipio').attr("disabled", true);
                break;
        }
    },

    clienteTpPessoa: function () {
        switch (oInfra.getProduto().getParametros().getItem('xcTpPessoa')) {
            case 'F':
                $('#txtCodClienteLista').val(oInfra.getProduto().getParametros().getItem('xcCodCli').substr(3));
                oInfra.getUtil().adicionarMascara('#txtCodClienteLista', '{cpf}');
                $("label[for='txtCodClienteLista']").html('CPF');
                $('#txtCodClienteLista').attr('mm-regras', 'cpf, required');
                $('#txtCodClienteCadastro').val(oInfra.getProduto().getParametros().getItem('xcCodCli').substr(3));
                oInfra.getUtil().adicionarMascara('#txtCodClienteCadastro', '{cpf}');
                $("label[for='txtCodClienteCadastro']").html('CPF');
                $('#txtCodClienteCadastro').attr('mm-regras', 'cpf, required');
                break;
            case 'J':
                $('#txtCodClienteLista').val(oInfra.getProduto().getParametros().getItem('xcCodCli'));
                oInfra.getUtil().adicionarMascara('#txtCodClienteLista', '{cnpj}');
                $('#txtCodClienteLista').attr('mm-regras', 'cnpj, required');
                $("label[for='txtCodClienteLista']").html('CNPJ');
                $('#txtCodClienteCadastro').val(oInfra.getProduto().getParametros().getItem('xcCodCli'));
                oInfra.getUtil().adicionarMascara('#txtCodClienteCadastro', '{cnpj}');
                $('#txtCodClienteCadastro').attr('mm-regras', 'cnpj, required');
                $("label[for='txtCodClienteCadastro']").html('CNPJ');
                break;
            default:
                oInfra.getTela().mensagem(
                    'Nenhum cliente selecionado.',
                    'Atenção',
                    ['Ok'],
                    [
                        function () {
                            oInfra.getServidor().invocarPagina('M5CL');
                        },
                    ]
                );
                return;
        }
    },

    clicarNovo: function () {
        oInfra.getTela().limparCamposFormulario('#formCadastro');
        oInfra.getTela().mostrarTela('Cadastro', 'Inclusao');
        $('#txtCadastroCodMunicipio').attr("disabled", true);


    },
    formatarLinhaListaTabelalista: function (dados) {
        dados.cod_emprestimo_formatado = oInfra.getUtil().aplicarMascara(dados.cod_emprestimo, '');
        dados.dt_inclusao_formatado = oInfra.getUtil().aplicarMascara(dados.dt_inclusao, '00/00/0000');
        dados.agencia_formatado = oInfra.getUtil().aplicarMascara(dados.agencia, '');
        dados.valor_emp_formatado = oInfra.getUtil().aplicarMascara(dados.valor_emp, '9999999999999.00');
        dados.taxa_formatado = oInfra.getUtil().aplicarMascara(dados.taxa, '9.00');
        return dados;
    },
    clicarIncluir: function () {
        if (!oInfra.getUtil().validarFormulario('#formCadastro')) {
            return false;
        }

        var parms = oInfra.getTela().getParametros().oPares;
        parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
        parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
        //
        parms.cod_emprestimo = $('#txtCadastroCodEmprestimo').val().trim();
        parms.dt_inclusao = $('#txtCadastroDtInclusao').val().trim();
        parms.uf = $('#txtCadastroUf').val().trim();
        parms.cod_municipio = $('#txtCadastroCodMunicipio').val().trim();
        parms.valor_emp = $('#txtCadastroValorEmp').val().trim();
        parms.taxa = $('#txtCadastroTaxa').val().trim();
        parms.dt_pagto = $('#txtCadastroDtPagto').val().trim();
        parms.dt_cancelamento = $('#txtCadastroDtCancelamento').val().trim();
        parms.cod_operador = $('#txtCadastroCodOperador').val().trim();
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Incluir', {
            parametros: parms
        });
    },
    clicarSalvar: function () {
        if (!oInfra.getUtil().validarFormulario('#formCadastro')) {
            return false;
        }

        var parms = oInfra.getTela().getParametros().oPares;
        parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
        parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
        //
        parms.cod_emprestimo = $('#txtCadastroCodEmprestimo').val().trim();
        parms.dt_inclusao = $('#txtCadastroDtInclusao').val().trim();
        parms.agencia = $('#txtCadastroAgencia').val().trim();
        parms.uf = $('#txtCadastroUf').val().trim();
        parms.cod_municipio = $('#txtCadastroCodMunicipio').val().trim();
        parms.valor_emp = $('#txtCadastroValorEmp').val().trim();
        parms.taxa = $('#txtCadastroTaxa').val().trim();
        parms.dt_pagto = $('#txtCadastroDtPagto').val().trim();
        parms.dt_cancelamento = $('#txtCadastroDtCancelamento').val().trim();
        parms.cod_operador = $('#txtCadastroCodOperador').val().trim();
        parms.ult_atualizacao = $('#txtCadastroUltAtualizacao').val().trim();
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Alterar', {
            parametros: parms
        });
    },
    clicarExcluir: function () {
        oInfra.getTela().mensagem(
            'Confirma a exclusão do registro?',
            'Atenção',
            ['Sim', 'Não'],
            [
                function () {
                    oInfra.getTela().fecharMensagem();

                    var cod_emprestimo = $('#txtCadastroCodEmprestimo').val().trim();
                    var ult_atualizacao = $('#txtCadastroUltAtualizacao').val().trim();
                    var parms = oInfra.getTela().getParametros().oPares;

                    parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
                    parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
                    //
                    parms.cod_emprestimo = cod_emprestimo;
                    parms.ult_atualizacao = ult_atualizacao;
                    oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Excluir', {
                        parametros: parms
                    });
                },
                function () {
                    oInfra.getTela().fecharMensagem();
                }
            ]
        );
    },
    
    clicarPesquisar: function () {
        var parms = oInfra.getTransacao().getParametros().oPares;
        parms.xcCodCli = oInfra.getProduto().getParametros().getItem('xcCodCli');
        parms.xcTpPessoa = oInfra.getProduto().getParametros().getItem('xcTpPessoa');
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/ListarPrimeiraPagina', {
            parametros: parms,
            retorno: oInfra.getUtil().tratarRetornoListar
        });
        oInfra.getTela().clicarBotaoPrimeiraPagina();
    },
    
    tratarRetornoObterboxDadosCadastro: function (oJson) {
        if (oInfra.getJsonUtil().confirmarSucesso(oJson)) {
            if (oJson.dados) {        
                
                var a = oJson.dados.registrousuario.agencia;
                a = a.padStart(4,'0');
                
                oInfra.getTela().popularCamposFormulario('#formCadastro', {
                    situacao:oJson.dados.registrousuario.situacao,
                    cod_emprestimo: oJson.dados.registrousuario.cod_emprestimo,
                    dt_inclusao: oJson.dados.registrousuario.dt_inclusao,
                    uf: oJson.dados.registrousuario.uf,
                    agencia: a,
                    cod_municipio: oJson.dados.registrousuario.cod_municipio,
                    valor_emp: oJson.dados.registrousuario.valor_emp,
                    taxa: oJson.dados.registrousuario.taxa,
                    dt_pagto: oJson.dados.registrousuario.dt_pagto,
                    dt_cancelamento: oJson.dados.registrousuario.dt_cancelamento,
                    cod_operador: oJson.dados.registrousuario.cod_operador,
                    ult_atualizacao: oJson.dados.registrousuario.ult_atualizacao,
                });   
                oPxcsemhn.carregarTxtCadastroCodMunicipio();

                switch (oJson.dados.registrousuario.situacao) {
                    case 'A':
                        $('[name="txtCadastroDtPagto"]').hide();
                        $('[name="txtCadastroDtCancelamento"]').hide();
                        break;
                    case 'C':
                            $('[name="txtCadastroDtPagto"]').hide();
                            $('[name="txtCadastroDtCancelamento"]').show();
                        break;
                    case 'P':
                            $('[name="txtCadastroDtPagto"]').show();
                            $('[name="txtCadastroDtCancelamento"]').hide();
                        break;
                
                    default:
                        break;
                }

                oInfra.getTela().mostrarTela('Cadastro', 'Consulta');

            }
        } else {
            oInfra.getTela().mensagem(oInfra.getJsonUtil().lerMensagem(oJson));
        }
    },
    exibirEmprestimo: function (cod_emprestimo) {
        var parms = oInfra.getTela().getParametros().oPares;
        parms.cod_emprestimo = cod_emprestimo;
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Obter', {
            parametros: parms,
            retorno: oPxcsemhn.tratarRetornoObterboxDadosCadastro
        });
    },
    excluirItemTabelaLista: function (cod_emprestimo) {
        oInfra.getTela().mensagem(
            'Confirma a exclusão do registro?',
            'Atenção',
            ['Sim', 'Não'],
            [
                function () {
                    oInfra.getTela().fecharMensagem();
                    var parms = oInfra.getTela().getParametros().oPares;
                    parms.cod_emprestimo = cod_emprestimo;
                    oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/Excluir', {
                        parametros: parms
                    });
                },
                function () {
                    oInfra.getTela().fecharMensagem();
                }
            ]
        );
    },

        carregarTxtCadastroAgencia: function () {
            oInfra.getServidor().invocarServico('Pxcwctxn_Contrato.asmx/CarregarCboAgencia',{
                parametros: oInfra.getTela().getParametros(),
                retorno: function (oJson) {
                    if (oInfra.getJsonUtil().confirmarSucesso(oJson)) {
                        if (!oJson.dados) {
                            return;
                        }
                        oInfra.getTela().renderizarCombo('#txtCadastroAgencia', oJson.dados);
                    } else {
                        oInfra.getTela().mensagem(oInfra.getJsonUtil().lerMensagem(oJson));
                    }
                }
            });
        },

    carregarTxtCadastroCodMunicipio: function () {
        $('#txtCadastroCodMunicipio').attr("disabled", false);
        var parms = oInfra.getTela().getParametros().oPares;
        parms.uf = $('#txtCadastroUf').val()
        oInfra.getServidor().invocarServico('Pxcwemxn_Emprestimo.asmx/ListarCodMunicipio', {
            parametros: parms,
            retorno: function (oJson) {
                if (oInfra.getJsonUtil().confirmarSucesso(oJson)) {
                    if (!oJson.dados) {
                        return;
                    }
                    oInfra.getTela().renderizarCombo('#txtCadastroCodMunicipio', oJson.dados);
                } else {
                    oInfra.getTela().mensagem(oInfra.getJsonUtil().lerMensagem(oJson));
                }
            }
        });
    },
    clicarOutro: function () {
        //TODO
    },

};
//Cancelar Pagar ExcluirLinha 
//lista taxa situacao